"""
Phase B test harness: the baseline agent, with the last-metre controller on top.

You drive with the arrows exactly as in baseline_agent.py. As soon as the baseline thinks you
are within --handoff hops of the goal node and you are not touching the keys, final_approach
takes over: it turns, creeps in, and checks in by itself. Any arrow, space or escape hands
control straight back to you.

    uv run source/final_agent.py --local 7

Each run prints the camera info and the final result, and writes logs/phase_b.csv with the
estimates behind every decision. Paste those back when tuning.
"""

from __future__ import annotations

from pathlib import Path

import cli
from baseline_agent import BaselineAgent
from final_approach import FinalApproach, intrinsics
from vis_nav_sdk import WAIT, Observation, SessionInfo, run


class FinalAgent(BaselineAgent):
    def __init__(self, data_dir: Path, *, handoff_hops: int = 5, **kwargs) -> None:
        super().__init__(data_dir, **kwargs)
        self.handoff_hops = handoff_hops
        self.final: FinalApproach | None = None

    def setup(self, info: SessionInfo) -> None:
        super().setup(info)
        print("camera:", info.camera)
        print("limits:", info.limits)
        K = intrinsics(info.camera, info.targets[0].shape)
        print("K =\n", K)
        self.final = FinalApproach(K, info.targets)

    def act(self, obs: Observation):
        action = super().act(obs)  # localises, then reads the keyboard
        keys_held = not (action is WAIT or action == WAIT)
        near = len(self.path) - 1 <= self.handoff_hops
        if keys_held or not near or self.final is None:
            return action
        move = self.final.step(obs.image, obs.steps_left)
        return action if move is None else move

    def hud(self) -> list[str]:
        lines = super().hud()
        if self.final is not None:
            lines.append(f"phase B: {self.final.status}")
        return lines

    def finish(self, result) -> None:
        print("result:", result)
        if self.final is not None:
            self.final.dump_csv(Path("logs") / "phase_b.csv")
            print("wrote logs/phase_b.csv")


if __name__ == "__main__":
    parser = cli.parser(__doc__)
    parser.add_argument("--data", help="exploration data directory (default: download)")
    parser.add_argument("--subsample", type=int, default=5, help="keep every Nth frame")
    parser.add_argument("--n-clusters", type=int, default=128, help="VLAD codebook size")
    parser.add_argument("--top-k", type=int, default=30, help="visual shortcut edges")
    parser.add_argument("--handoff", type=int, default=5, help="hand over at this many hops")
    args = parser.parse_args()

    challenge = cli.challenge(args)
    agent = FinalAgent(
        cli.exploration_data(args, args.data),
        handoff_hops=args.handoff,
        n_clusters=args.n_clusters,
        subsample=args.subsample,
        top_k_shortcuts=args.top_k,
        cache_dir=Path("cache") / challenge.replace(":", "-"),
    )
    run(agent, challenge, **cli.run_options(args))
